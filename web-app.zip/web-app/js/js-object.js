var dataArray = [
	{
		id:1,
		name: 'motorbike',
		hire: 109,
		fuel: 3.7,

	},
	{
		id:2,
		name: 'small car',
		hire: 129,
		fuel: 8.5
	},
	{
		id:3,
		name: 'large car',
		hire: 144,
		fuel: 9.7
	},
	{
		id:4,
		name:'motor home',
		hire:200,
		fuel:17
	}
	

];

var dataArray2 = [
		{
			id:1,
			name: 'auckland',
			waitomo: 196,
			rotorua: 219,
			tauranga: 213,
			taupo: 274,
			matamata: 176,
			castlepoint: 672,
		},
		{
			id:2,
			name: 'wellington',
			waitomo: 465,
			rotorua: 461,
			tauranga: 523,
			taupo: 376,
			matamata: 492,
			castlepoint: 164,
		},
		{
			id:3,
			name: 'new plymouth',
			waitomo: 181,
			rotorua: 303,
			tauranga: 313,
			taupo: 280,
			matamata: 265,
			castlepoint: 388,
		},
		{
			id:4,
			name: 'naiper',
			waitomo: 291,
			rotorua: 228,
			tauranga: 290,
			taupo: 150,
			matamata: 256,
			castlepoint: 293 
		}
];

